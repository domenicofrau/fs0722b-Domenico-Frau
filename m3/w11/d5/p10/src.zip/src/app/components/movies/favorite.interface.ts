export interface Favorite {
  userId: number,
  movieId: number,
  id: number
}
