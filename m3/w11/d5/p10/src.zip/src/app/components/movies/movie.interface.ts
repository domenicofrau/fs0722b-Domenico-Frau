export interface Movie {
    id:number;
    poster_path:string;
    title:string;
    like:boolean;
}
